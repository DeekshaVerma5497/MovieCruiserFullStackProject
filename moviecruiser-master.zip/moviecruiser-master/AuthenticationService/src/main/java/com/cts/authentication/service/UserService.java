package com.cts.authentication.service;

import com.cts.authentication.domain.User;
import com.cts.authentication.exception.UserAlreadyExistsException;
import com.cts.authentication.exception.UserNotFoundException;

public interface UserService {

	boolean saveUser(User user) throws UserAlreadyExistsException;

	User findByUserIdAndPassword(String userId, String password) throws UserNotFoundException;
	
}
