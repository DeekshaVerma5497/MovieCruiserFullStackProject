cd Backend
source ./env-variable.sh
mvn clean package
cd ..
cd AuthenticationService
source ./env-variable.sh
mvn clean package
cd ..
