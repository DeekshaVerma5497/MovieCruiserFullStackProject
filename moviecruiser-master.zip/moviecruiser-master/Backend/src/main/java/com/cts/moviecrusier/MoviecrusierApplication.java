package com.cts.moviecrusier;

import org.springframework.boot.SpringApplication;
import javax.servlet.Filter;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

import com.cts.moviecrusier.filter.JwtFilter;

@SpringBootApplication
public class MoviecrusierApplication {
	
	@Bean
	public FilterRegistrationBean<Filter> jwtFilter() {
		final FilterRegistrationBean<Filter> registrationBean = new FilterRegistrationBean<>();
		registrationBean.setFilter(new JwtFilter());
		registrationBean.addUrlPatterns("/api/*");
		return registrationBean;
	}


	/**
	 * main class through which boot application starts
	 */

	public static void main(String[] args) {
		SpringApplication.run(MoviecrusierApplication.class, args);
	}

}
