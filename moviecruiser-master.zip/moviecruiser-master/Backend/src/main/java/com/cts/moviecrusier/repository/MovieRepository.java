package com.cts.moviecrusier.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.moviecrusier.domain.Movie;

/**
 * Crud Repository for Movie class
 */

@Repository
public interface MovieRepository extends JpaRepository<Movie, Integer> {

	public Movie findByTitle(String title);
	
	@Query("from Movie m where m.movie_id=:mId")
	public Optional<Movie> findByMovieId(@Param("mId") int mId);
	
	List<Movie> findByUserId(String userId);
	
}
