package com.cts.moviecrusier.exception;

@SuppressWarnings("serial")
public class MovieAlreadyExistsException extends Exception {
	/**
	 * custom exception for when we try to add an existing movie again into database
	 * 
	 * @param message
	 */
	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public MovieAlreadyExistsException(final String message) {
		super(message);
		this.message = message;
	}

	@Override
	public String toString() {
		return "MovieAlreadyExistsException [message=" + message + "]";
	}
}
