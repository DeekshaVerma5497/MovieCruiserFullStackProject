package com.cts.moviecrusier.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.moviecrusier.domain.Movie;
import com.cts.moviecrusier.exception.MovieAlreadyExistsException;
import com.cts.moviecrusier.exception.MovieNotFoundException;
import com.cts.moviecrusier.repository.MovieRepository;

/**
 * service class to implement all methods declared in MovieService interface
 */
@Service
public class MovieServiceImpl implements MovieService {

	/**
	 * reference to movieRepo object
	 */
	public final transient MovieRepository movieRepo;

	/**
	 * initializing the movieRepo object
	 * 
	 * @param movieRepo
	 */
	@Autowired
	public MovieServiceImpl(MovieRepository movieRepo) {
		super();
		this.movieRepo = movieRepo;
	}

	/**
	 * save the movie
	 */
	@Override
	public boolean saveMovie(Movie movie) throws MovieAlreadyExistsException {
		int mId=movie.getId();
		final Optional<Movie> object = movieRepo.findByMovieId(mId);
		if (object.isPresent()) {
			throw new MovieAlreadyExistsException("Could not save movie, Movie already exists");
		}
		movie.setMovie_id(mId);
		movieRepo.save(movie);
		return true;

	}

	/**
	 * update the movie comments
	 */
	@Override
	public Movie updateMovie(Movie updateMovie) throws MovieNotFoundException {
		final Movie movie = movieRepo.findById(updateMovie.getId()).orElse(null);
		if (movie == null) {
			throw new MovieNotFoundException("Could not update. Movie not found");
		}
		movie.setComments(updateMovie.getComments());
		movieRepo.save(movie);
		return movie;

	}

	/**
	 * delete movie of specific id
	 */
	@Override
	public boolean deleteMovieById(int id) throws MovieNotFoundException {
		final Movie movie = movieRepo.findById(id).orElse(null);
		if (movie == null) {
			throw new MovieNotFoundException("Could not delete. Movie not found");
		}
		movieRepo.delete(movie);
		return true;

	}

	/**
	 * get movie of specific id
	 */
	@Override
	public Movie getMovieById(int id) throws MovieNotFoundException {
		final Movie movie = movieRepo.findById(id).get();
		if (movie == null) {
			throw new MovieNotFoundException("Movie not found");
		}
		return movie;

	}

	/**
	 * get all movies
	 */
	@Override
	public List<Movie> getAllMovies(String userId) {
		return movieRepo.findByUserId(userId);
	}

}
