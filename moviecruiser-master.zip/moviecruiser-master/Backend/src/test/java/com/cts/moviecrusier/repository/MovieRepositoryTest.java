package com.cts.moviecrusier.repository;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.cts.moviecrusier.MoviecrusierApplication;
import com.cts.moviecrusier.domain.Movie;

import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Transactional
public class MovieRepositoryTest {


	@Autowired
	private transient MovieRepository movieRepository;

	public void setMovieRepository(MovieRepository movieRepository) {
		this.movieRepository = movieRepository;
	}
	
	private transient Movie movie;
	
	@Before
	public void setUp()
	{
		MockitoAnnotations.initMocks(this);
		movie = new Movie("superman", "A good movie", "www.abc.com", "2015-03-23","1");
	}
	
	@After 
	public void delete()
	{
		movieRepository.deleteAllInBatch();
	}
	
	@Test
	public void testSaveMovie() throws Exception {
		movieRepository.save(movie);
		final Movie movie = movieRepository.findByTitle("superman");
		assertEquals("superman", movie.getTitle());
	}
	
	@Test
	public void testUpdateMovie() throws Exception {
		movieRepository.save(movie);
		final Movie movie = movieRepository.findByTitle("superman");
		assertEquals("superman", movie.getTitle());
		movie.setComments("Hi");
		movieRepository.save(movie);
		final Movie tempMovie = movieRepository.findByTitle("superman");
		assertEquals("Hi", tempMovie.getComments());
	}
	
	@Test
	public void testDeleteMovie() throws Exception {
		movieRepository.save(movie);
		final Movie tempMovie = movieRepository.findByTitle("superman");
		assertEquals("superman", movie.getTitle());
		movieRepository.delete(movie);
		assertEquals(Optional.empty(), movieRepository.findById(1));
	}
	
	@Test
	public void testGetMovie() throws Exception {
		movieRepository.save(movie);
		final Movie tempMovie = movieRepository.findByTitle("superman");
		assertEquals("superman", movie.getTitle());
	}
	
	@Test
	public void testGetMyMovies() throws Exception {
		movieRepository.save(movie);
		final List<Movie> movies = movieRepository.findByUserId("1");
		assertEquals("superman", movies.get(0).getTitle());
	}





}
