package com.cts.moviecrusier.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doNothing;

import com.cts.moviecrusier.domain.Movie;
import com.cts.moviecrusier.exception.MovieAlreadyExistsException;
import com.cts.moviecrusier.exception.MovieNotFoundException;
import com.cts.moviecrusier.repository.MovieRepository;

public class MovieServiceTest {

	@Mock
	MovieRepository movieRepository;

	private Movie movie;

	/**
	 * creating a object of MovieServiceImpl class and injecting it into the mockito
	 * object
	 */
	@InjectMocks
	MovieServiceImpl serviceImpl;

	Optional<Movie> newMovie;

	List<Movie> movieList = new ArrayList<Movie>();

	/**
	 * creating mock data
	 */
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		movie = new Movie("De Dana Dan", "Awesome", "dana.jpg", "05/04/2007","1");

		movieList.add(movie);
		movie = new Movie("Bindass", "Fussss", "bindass.jpg", "26/01/2009","1");
		movie.setId(1);
		newMovie = Optional.of(movie);

	}

	@Test
	public void testMockCreation() {
		assertNotNull("Jpa repository creation failed: use @InjectMocks on serviceImpl", movie);
	}

	/**
	 * service test for success on save movie
	 * 
	 * @throws MovieAlreadyExistsException
	 */
	@Test
	public void testSaveMovieSuccess() throws MovieAlreadyExistsException {
		when(movieRepository.save(movie)).thenReturn(movie);
		final boolean flag = serviceImpl.saveMovie(movie);
		assertTrue("Saving Movie Failed", flag);
		verify(movieRepository, times(1)).findByMovieId(Mockito.anyInt());
	}

	/**
	 * service test for failure on save movie
	 * 
	 * @throws MovieAlreadyExistsException
	 */
	@Test(expected = MovieAlreadyExistsException.class)
	public void testSaveMovieFailure() throws MovieAlreadyExistsException {
		when(movieRepository.findByMovieId(1)).thenReturn(newMovie);
		when(movieRepository.save(movie)).thenReturn(movie);
		final boolean flag = serviceImpl.saveMovie(movie);
		assertFalse("Saving Movie Failed", flag);
		verify(movieRepository, times(1)).findByMovieId(Mockito.anyInt());
	}

	/**
	 * service test for success on update movie
	 * 
	 * @throws MovieNotFoundException
	 */
	@Test
	public void testUpdateMovie() throws MovieNotFoundException {
		when(movieRepository.findById(1)).thenReturn(newMovie);
		when(movieRepository.save(movie)).thenReturn(movie);
		movie.setComments("Not so good movie");
		final Movie movie1 = serviceImpl.updateMovie(movie);
		assertEquals("Updating Moving Fails", "Not so good movie", movie1.getComments());
		verify(movieRepository, times(1)).save(movie);
		verify(movieRepository, times(1)).findById(Mockito.anyInt());
	}

	/**
	 * service test for success on delete movie
	 * 
	 * @throws MovieNotFoundException
	 */
	@Test
	public void testDeleteByMovieId() throws MovieNotFoundException {
		when(movieRepository.findById(1)).thenReturn(newMovie);
		doNothing().when(movieRepository).delete(movie);
		final boolean flag = serviceImpl.deleteMovieById(1);
		assertTrue("Movie Deleted", flag);
		verify(movieRepository, times(1)).delete(movie);
		verify(movieRepository, times(1)).findById(Mockito.anyInt());
	}

	/**
	 * service test for success on fetching movie by Id
	 * 
	 * @throws MovieNotFoundException
	 */
	@Test
	public void testGetMovieById() throws MovieNotFoundException {
		when(movieRepository.findById(1)).thenReturn(newMovie);
		final Movie movie1 = serviceImpl.getMovieById(1);
		assertEquals("Movie Found", movie1, movie);
		verify(movieRepository, times(1)).findById(Mockito.anyInt());
	}

	/**
	 * service test for success on fetching all movies
	 * 
	 * @throws MovieNotFoundException
	 */
	@Test
	public void testGetAllMovies() throws MovieNotFoundException {
		when(movieRepository.findByUserId("1")).thenReturn(movieList);
		final List<Movie> movies = serviceImpl.getAllMovies("1");
		assertEquals(movieList, movies);
		verify(movieRepository, times(1)).findByUserId("1");
	}

}
