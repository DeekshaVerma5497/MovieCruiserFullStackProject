cd Backend
source ./env-variable.sh
cd ..
cd AuthenticationService
source ./env-variable.sh
cd ..
